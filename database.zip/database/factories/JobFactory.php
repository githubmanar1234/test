<?php

namespace Database\Factories;

use App\Helpers\Constants;
use App\Models\Job;
use Illuminate\Database\Eloquent\Factories\Factory;

class jobFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Job::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'title' => $this->faker->word,
            'description' => $this->faker->text,
            'location' => $this->faker->randomFloat(),
            'freelancer' => $this->faker->boolean,
            'image' => "https://picsum.photos/id/1/200/300",
            'subcategory_id' => null,
            'user_id' => null,
            'status' => (Constants::STATUS_UNDER_REVIEW),
            'reject_message' => $this->faker->sentence
        ];
    }
}
