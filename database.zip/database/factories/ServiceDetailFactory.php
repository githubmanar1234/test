<?php

namespace Database\Factories;

use App\Helpers\Constants;
use App\Models\Service;
use App\Models\ServiceDetail;
use Illuminate\Database\Eloquent\Factories\Factory;

class ServiceDetailFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = ServiceDetail::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'facebook_link' => $this->faker->url,
            'phone_number' => $this->faker->phoneNumber,
            'whatsapp_number' => $this->faker->phoneNumber,
            'qualification' => $this->faker->word,
        ];
    }
}
