<?php

namespace Database\Factories;

use App\Helpers\Constants;
use App\Models\JobDetail;
use App\Models\Service;
use App\Models\ServiceDetail;
use Illuminate\Database\Eloquent\Factories\Factory;

class JobDetailFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = JobDetail::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [

            'qualification' => $this->faker->word,
            'working_hours' => $this->faker->randomNumber(2),
            'working_days' => $this->faker->randomNumber(2),
            'experience_years' => $this->faker->randomNumber(2),
            'salary' =>  $this->faker->randomNumber(4),
            'phone_number' => $this->faker->phoneNumber,
            'email' => $this->faker->email
        ];
    }
}
