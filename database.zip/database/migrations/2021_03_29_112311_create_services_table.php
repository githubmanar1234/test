<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateServicesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('services', function (Blueprint $table) {
            $table->id();
            $table->text('title');
            $table->text('description');
            $table->string('image', 255);
            $table->string('location');
            $table->boolean('have_store')->default(false);
            $table->text('reject_message')->nullable('true');
            $table->string('status')->default(\App\Helpers\Constants::STATUS_UNDER_REVIEW);

            $table->unsignedBigInteger('user_id');
            $table->unsignedBigInteger('parent_id')->nullable();
            $table->unsignedBigInteger('subcategory_id');
            $table->unsignedBigInteger('city_id');
            $table->text('qualification')->nullable();
            $table->string('facebook_link')->nullable(true);
            $table->string('phone_number')->nullable(true);
            $table->string('whatsapp_number')->nullable(true);
            $table->string('email')->nullable(true);
            // $table->foreign('city_id')->references('id')->on('cities')->nullOnDelete()->cascadeOnUpdate();
            // $table->foreign('user_id')->references('id')->on('users')->cascadeOnDelete()->cascadeOnUpdate();
            // $table->foreign('subcategory_id')->references('id')->on('categories')->cascadeOnDelete()->cascadeOnUpdate();
            // $table->foreign('parent_id')->references('id')->on('services')->cascadeOnDelete()->cascadeOnUpdate();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('services');
    }
}
