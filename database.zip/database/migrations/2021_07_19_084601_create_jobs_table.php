<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateJobsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('jobs', function (Blueprint $table) {
            $table->id();
            $table->text('title');
            $table->text('description');
            $table->string('location');
            $table->string('image', 255);
            $table->boolean('freelancer')->default(false);
            $table->text('reject_message')->nullable('true');
            $table->string('status')->default(\App\Helpers\Constants::STATUS_UNDER_REVIEW);
            $table->text('qualification')->nullable();
            $table->double('working_hours')->nullable(true);
            $table->double('working_days')->nullable(true);
            $table->double('experience_years')->nullable(true);
            $table->text('phone_number')->nullable(true);
            $table->unsignedBigInteger('parent_id')->nullable();
            $table->foreign('parent_id')->references('id')->on('jobs')->cascadeOnDelete()->cascadeOnUpdate();
            $table->text('email')->nullable(true);
            $table->integer('salary')->nullable(true);
            $table->unsignedBigInteger('city_id');
            // $table->foreign('city_id')->references('id')->on('cities')->nullOnDelete()->cascadeOnUpdate();
            $table->unsignedBigInteger('user_id');
            $table->unsignedBigInteger('subcategory_id');
            $table->foreign('user_id')->references('id')->on('users')->cascadeOnDelete()->cascadeOnUpdate();
            $table->foreign('subcategory_id')->references('id')->on('categories')->cascadeOnDelete()->cascadeOnUpdate();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('jobs');
    }
}
