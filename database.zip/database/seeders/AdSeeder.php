<?php

namespace Database\Seeders;

use App\Models\Ad;
use App\Models\Category;
use App\Models\Job;
use App\Models\JobDetail;
use App\Models\Service;
use App\Models\ServiceDetail;
use App\Models\User;
use Illuminate\Database\Seeder;

class AdSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = User::factory()->create();
        $ads = Ad::factory()->count(5)->create();
    }
}